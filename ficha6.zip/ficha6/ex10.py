listaEspera = []
p = 20
while p != 0:
    p = int(input("MENU \n 1 – Tirar Ticket \n 2 - Atendimento \n 3 - Estado da fila de espera \n 0 - Sair"))
    if p == 1:
        def primeiroLugar():
             = listaEspera.insert[0]